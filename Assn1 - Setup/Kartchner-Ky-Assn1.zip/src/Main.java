/**
 * Main: Prints a message that includes my first and last name to the console.
 *
 * @author Ky Kartchner
 * @version 1.0
 */
public class Main {
    private String fName = "Ky";
    private String lName = "Kartchner";

    public static void main(String[] args){
        Main mainClass = new Main();
        mainClass.printName();
    }

    public void printName() {
        System.out.println("Greetings, World! My name is " + fName + " " + lName + "!");
    }
}
