/**
 * public Enumerator of treasure types.
 *
 * @author Ky Kartchner
 * @version 1.0
 */
public enum Treasure {
    Wood,
    Statue,
    Coins,
    Food,
    Rags
}
