/**
 * Generates a series of random arrays (sized 1000 to 10,000 in increments of 1000), sorts them using the Bubble Sort
 * and Selection Sort, and reports the time it took for each one.
 *
 * @author Ky Kartchner
 * @version 1.0
 */
public class SortingDriver {
    /**
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        System.out.println("--- Timing Results ---\n");

        for (int i = 1; i <= 10; i++){
            int numberOfItems = i * 1000;
            int[] data1 = generateNumbers(numberOfItems);
            int[] data2 = generateNumbers(numberOfItems);

            SortingStats bubbleStats = bubbleSort(data1);
            SortingStats selectionStats = selectionSort(data2);

            System.out.println("Number of items      : " + numberOfItems);
            System.out.println("Bubble sort time     : " + bubbleStats.getTimeInMs() + " ms");
            System.out.println("Selection sort time  : " + selectionStats.getTimeInMs() + " ms\n");

        }

    }

    /**
     * Creates and returns an array of random integers from 0 to 100,000
     * @param howMany The number of integers to generate
     * @return The newly created array
     */
    public static int[] generateNumbers(int howMany){
        int[] intArray = new int[howMany];

        for (int i = 0; i < intArray.length; i++) {
            intArray[i] = (int)(Math.random() * 100_001);
        }

        return intArray;
    }

    /**
     * Sorts the passed in array from lowest to highest using the Bubble Sort Algorithm
     * @param data The array to be sorted
     * @return The sorting stats
     */
    public static SortingStats bubbleSort(int[] data){
        SortingStats bubbleStats = new SortingStats();          // Create new stats object

        long startTime = System.currentTimeMillis();            // Get start time
        boolean numbersWereSwapped = true;

        while (numbersWereSwapped){                             // Bubble Sort
            numbersWereSwapped = false;
            for (int i = 1; i < data.length; i++){
                if (data[i-1] > data[i]){
                    int temp = data[i];
                    data[i] = data[i-1];
                    data[i-1] = temp;

                    bubbleStats.incrementSwapCount();
                    numbersWereSwapped = true;
                }
                bubbleStats.incrementCompareCount();
            }
        }

        long endTime = System.currentTimeMillis();              // Get end time
        bubbleStats.setTime(endTime - startTime);               // Store elapsed time to bubble stats

        return bubbleStats;
    }

    /**
     * Sorts the passed in array from lowest to highest using the Selection Sort Algorithm
     * @param data The array to be sorted
     * @return The sorting stats
     */
    public static SortingStats selectionSort(int[] data){
        SortingStats selectionStats = new SortingStats();               // Create new stats object
        long startTime = System.currentTimeMillis();                    // Get start time

        for (int j = 0, min = 0; j < data.length; j++, min = j){        // Selection sort
            for (int i = j + 1; i < data.length; i++) {
                if (data[i] < data[min]) {
                    min = i;
                }
                selectionStats.incrementCompareCount();
            }
            if (min != j) {
                int temp = data[j];
                data[j] = data[min];
                data[min] = temp;

                selectionStats.incrementSwapCount();
            }
        }

        long endTime = System.currentTimeMillis();                     // Get end time
        selectionStats.setTime(endTime - startTime);                   // Store elapsed time to selection stats

        return selectionStats;
    }
}
