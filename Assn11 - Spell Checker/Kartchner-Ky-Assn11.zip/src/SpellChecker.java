import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * SpellChecker.java reads in the provided dictionary into a array list, randomizes the order of the list, then adds the words into a
 * binary search tree of the BinarySearchTree class. Then reads in the provided letter and checks each word to see if
 * it is contained in the dictionary and prints the list of words that are not found.
 *
 * @author Ky Kartchner
 * @version 1.0
 */
public class SpellChecker {
    /**
     * Main driver code
     *
     * @param args Commandline arguments
     */
    public static void main(String[] args) {
        BinarySearchTree<String> dictionary = readDictionary();
        reportTreeStats(dictionary);

        System.out.println();

        ArrayList<String> letter = readLetter();

        System.out.println("The following words from the letter are not in the provided dictionary: ");
        for (String word : letter){
            if (dictionary.search(word.toLowerCase()) == false){
                System.out.println(word);
            }
        }
        //testTree();
    }

    /**
     * Reports the stats of the specified binary search tree.
     *
     * @param tree The binary search tree to print the stats of.
     */
    public static void reportTreeStats(BinarySearchTree<String> tree) {
        System.out.println("-- Tree Stats --");
        System.out.printf("Total Nodes : %d\n", tree.numberNodes());
        System.out.printf("Leaf Nodes  : %d\n", tree.numberLeafNodes());
        System.out.printf("Tree Height : %d\n", tree.height());
    }

    /**
     * Reads in the words from the "Dictionary.txt" file, randomize the collection, then store the words into a
     * new binary search tree.
     *
     * @return The newly created binary search tree.
     */
    public static BinarySearchTree<String> readDictionary() {
        System.out.println("Reading in provided dictionary...");

        BinarySearchTree<String> tree = new BinarySearchTree<>();

        Scanner fileInput = null;
        try {
            fileInput = new Scanner(new FileReader("Dictionary.txt"));
        } catch (FileNotFoundException e){
            e.printStackTrace();
        }

        ArrayList<String> words = new ArrayList<>();
        while (fileInput.hasNextLine()){
            words.add(fileInput.nextLine());
        }

        java.util.Collections.shuffle(words, new java.util.Random(System.currentTimeMillis()));

        for (String word : words){
            tree.insert(word);
        }

        fileInput.close();

        System.out.println("Dictionary successfully read in.\n");
        return tree;
    }

    /**
     * Read in the words from the "Letter.txt" file and store them into a new array list of strings.
     *
     * @return The newly created ArrayList
     */
    public static ArrayList<String> readLetter(){
        System.out.println("Reading in provided letter...");

        Scanner fileInput = null;
        try {
            fileInput = new Scanner(new FileReader("Letter.txt"));
        } catch (FileNotFoundException e){
            e.printStackTrace();
        }

        ArrayList<String> words = new ArrayList<>();
        while (fileInput.hasNextLine()){
            String[] currentLine = fileInput.nextLine().split(" ");
            for (String word : currentLine){
                word = word.replaceAll("\\p{IsPunctuation}|\\p{IsWhite_Space}", "");

                if (!word.equals("")) {
                    words.add(word);
                }
            }
        }

        System.out.println("Letter has been successfully read in.\n");
        return words;
    }
}
