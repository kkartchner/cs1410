/**
 * Class definition for the Binary Search Tree used with the SpellChecker class.
 *
 * @author Ky Kartchner
 * @version 1.0
 */

public class BinarySearchTree<E extends Comparable<E>> {
    private TreeNode<E> root;
    private int numberOfNodes;

    public BinarySearchTree() {
        numberOfNodes = 0;
    }

    /**
     * Inserts a value into the tree without allowing duplicates.
     *
     * @param value The value to add to the tree.
     * @return True if value was added. False if it already exists in the tree.
     */
    boolean insert(E value) {
        if (root == null) {
            root = new TreeNode<>(value);
        } else {
            // Locate the parent node
            TreeNode<E> parent = null;
            TreeNode<E> current = root;

            while (current != null) {
                if (value.compareTo(current.value) < 0) {        // value is "less than" current value
                    parent = current;
                    current = current.leftChild;
                } else if (value.compareTo(current.value) > 0) {  // value is "greater than" current value
                    parent = current;
                    current = current.rightChild;
                } else {
                    return false;                   // value is a duplicate, so return false
                }
            }

            if (value.compareTo(parent.value) < 0) {
                parent.leftChild = new TreeNode<>(value);
            } else {
                parent.rightChild = new TreeNode<>(value);
            }
        }
        numberOfNodes++;
        return true;
    }

    /**
     * Removes the specified value from the tree if it exists.
     *
     * @param value The value to be deleted.
     * @return True if successfully deleted. False if value was not found.
     */
    boolean remove(E value) {
        if (numberOfNodes == 0) {
            return false;
        } else {
            TreeNode<E> current = root;
            TreeNode<E> parent = null;

            while (current != null) {
                if (value.compareTo(current.value) < 0) {        // If value is "less than" current value
                    parent = current;
                    current = current.leftChild;
                } else if (value.compareTo(current.value) > 0) {  // Else if value is "greater than" current value
                    parent = current;
                    current = current.rightChild;
                } else {
                    break;                                        // Else value was found, so break out of the search
                }
            }

            if (current == null) {       // If current is null after the search, the number was not found so return false
                return false;
            }

            boolean hasNoChildren = (current.leftChild == null && current.rightChild == null);
            boolean hasOnlyLeftChild = (current.leftChild != null && current.rightChild == null);
            boolean hasOnlyRightChild = (current.leftChild == null && current.rightChild != null);

            if (hasNoChildren) {
                if (current == root) {
                    root = null;
                } else {
                    if (current.value.compareTo(parent.value) > 0) {
                        parent.rightChild = null;
                    } else {
                        parent.leftChild = null;
                    }
                }
            } else if (hasOnlyLeftChild) {
                if (current == root) {
                    root = current.leftChild;
                } else {
                    if (current.value.compareTo(parent.value) > 0) {
                        parent.rightChild = null;
                    } else {
                        parent.leftChild = null;
                    }
                }
            } else if (hasOnlyRightChild) {
                if (current == root) {
                    root = current.rightChild;
                } else {
                    if (current.value.compareTo(parent.value) > 0) {
                        parent.rightChild = current.rightChild;
                    } else {
                        parent.leftChild = current.rightChild;
                    }

                }
            } else {        // Else current node has both a left and right child
                /* Remove current node by replacing it with it's lowest valued right child: */
                TreeNode<E> startParent = parent = current;
                current = current.rightChild;

                boolean wentLeft = false;

                while (current.leftChild != null) {
                    parent = current;
                    current = current.leftChild;
                    wentLeft = true;
                }

                startParent.value = current.value;

                if (wentLeft) {
                    parent.leftChild = null;
                } else {
                    parent.rightChild = null;
                }
            }
            numberOfNodes--;        // Decrease number of nodes by one.
        }
        return true;
    }

    /**
     * Searches for the specified value to see if it exists in the tree.
     *
     * @param value The value to search for.
     * @return True if value is found. False if not.
     */
    boolean search(E value) {
        TreeNode<E> current = root;
        TreeNode<E> parent = null;

        while (current != null) {
            if (value.compareTo(current.value) < 0) {        // value is "less than" current value
                parent = current;
                current = current.leftChild;
            } else if (value.compareTo(current.value) > 0) {  // value is "greater than" current value
                parent = current;
                current = current.rightChild;
            } else {
                return true;                   // value found, so return true
            }
        }
        return false;
    }


    /**
     * Returns the number of nodes contained in the binary search tree.
     * @return numberOfNodes
     */
    int numberNodes() {
        return numberOfNodes;
    }

    /**
     * Returns the number of leaf nodes in the binary tree by calling the countLeafNodes recursive function.
     *
     * @return The value returned from countLeafNodes(root).
     */
    int numberLeafNodes() {
        return countLeafNodes(root);
    }

    /**
     * Counts the number of leaf nodes (nodes that have no children).
     *
     * @param node Current node that is being checked.
     * @return 1 if node has no children or 0 if it is null.
     */
    private int countLeafNodes(TreeNode<E> node) {
        if (node == null) {
            return 0;
        }
        if (node.leftChild == null && node.rightChild == null) {
            return 1;
        } else {
            return countLeafNodes(node.leftChild) + countLeafNodes(node.rightChild);
        }
    }

    /**
     * Returns the height of the binary tree by calling the calculateHeight recursive function.
     *
     * @return The return value of calculateHeight(root)
     */
    int height() {
        return calculateHeight(root);
    }

    /**
     * Calculates the height of the current node.
     *
     * @param node Current node being checked
     * @return
     */
    private int calculateHeight(TreeNode<E> node) {
        if (node == null) {
            return -1;
        }

        return Math.max(calculateHeight(node.leftChild), calculateHeight(node.rightChild)) + 1;
    }

    /**
     * Displays the binary tree.
     * @param message Header to have
     */
    void display(String message) {
        System.out.println(message);
        printSubTree(root);
    }

    /**
     * Prints the sub tree of the specified node.
     * @param node The node to be printed.
     */
    private void printSubTree(TreeNode<E> node) {
        if (node != null) {
            printSubTree(node.leftChild);
            System.out.println(node.value);
            printSubTree(node.rightChild);
        }
    }

    /**
     * Tree node class used with the binary tree.
     * @param <E>
     */
    public static class TreeNode<E> {
        private E value;
        private TreeNode<E> leftChild;
        private TreeNode<E> rightChild;

        public TreeNode(E value) {
            this.value = value;
        }
    }
}
